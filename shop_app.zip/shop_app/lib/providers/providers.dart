import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/mock_data.dart';
import '../models/product.dart';

// ---------- المنتجات والبحث ----------
final selectedCategoryProvider = StateProvider<String>((ref) => 'الكل');
final searchQueryProvider = StateProvider<String>((ref) => '');

final filteredProductsProvider = Provider<List<Product>>((ref) {
  final cat = ref.watch(selectedCategoryProvider);
  final q = ref.watch(searchQueryProvider).trim();
  return mockProducts.where((p) {
    final okCat = cat == 'الكل' || p.category == cat;
    final okQ = q.isEmpty || p.name.contains(q);
    return okCat && okQ;
  }).toList();
});

// ---------- السلة ----------
class CartNotifier extends Notifier<List<CartItem>> {
  @override
  List<CartItem> build() => [];

  void add(Product p) {
    final i = state.indexWhere((e) => e.product.id == p.id);
    if (i == -1) {
      state = [...state, CartItem(p, 1)];
    } else {
      state = [
        for (var j = 0; j < state.length; j++)
          if (j == i) CartItem(p, state[j].qty + 1) else state[j],
      ];
    }
  }

  void decrement(Product p) {
    final i = state.indexWhere((e) => e.product.id == p.id);
    if (i == -1) return;
    if (state[i].qty <= 1) {
      remove(p);
    } else {
      state = [
        for (var j = 0; j < state.length; j++)
          if (j == i) CartItem(p, state[j].qty - 1) else state[j],
      ];
    }
  }

  void remove(Product p) =>
      state = state.where((e) => e.product.id != p.id).toList();

  void clear() => state = [];
}

final cartProvider =
    NotifierProvider<CartNotifier, List<CartItem>>(CartNotifier.new);

final cartCountProvider = Provider<int>(
    (ref) => ref.watch(cartProvider).fold(0, (s, e) => s + e.qty));

final subtotalProvider = Provider<double>(
    (ref) => ref.watch(cartProvider).fold(0.0, (s, e) => s + e.total));

final shippingProvider =
    Provider<double>((ref) => ref.watch(subtotalProvider) >= 500 ? 0 : 25);

final grandTotalProvider = Provider<double>(
    (ref) => ref.watch(subtotalProvider) + ref.watch(shippingProvider));

// ---------- المفضلة ----------
class FavoritesNotifier extends Notifier<Set<String>> {
  @override
  Set<String> build() => {};

  void toggle(String id) {
    state = state.contains(id) ? ({...state}..remove(id)) : {...state, id};
  }
}

final favoritesProvider =
    NotifierProvider<FavoritesNotifier, Set<String>>(FavoritesNotifier.new);

// ---------- الطلبات ----------
class OrdersNotifier extends Notifier<List<Order>> {
  @override
  List<Order> build() => [];

  void place(List<CartItem> items, double total) {
    state = [
      Order(
        id: '#${1000 + state.length + 1}',
        items: items,
        total: total,
        date: DateTime.now(),
        status: 'قيد التجهيز',
      ),
      ...state,
    ];
  }
}

final ordersProvider =
    NotifierProvider<OrdersNotifier, List<Order>>(OrdersNotifier.new);

// ---------- المستخدم (تسجيل دخول تجريبي) ----------
class AuthNotifier extends Notifier<String?> {
  @override
  String? build() => null;
  void login(String name) => state = name;
  void logout() => state = null;
}

final userProvider = NotifierProvider<AuthNotifier, String?>(AuthNotifier.new);

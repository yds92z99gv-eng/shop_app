class Product {
  final String id;
  final String name;
  final String description;
  final String category;
  final String image;
  final double price;
  final double? oldPrice;
  final double rating;
  final int reviews;

  const Product({
    required this.id,
    required this.name,
    required this.description,
    required this.category,
    required this.image,
    required this.price,
    this.oldPrice,
    this.rating = 4.5,
    this.reviews = 0,
  });
}

class CartItem {
  final Product product;
  final int qty;
  const CartItem(this.product, this.qty);
  double get total => product.price * qty;
}

class Order {
  final String id;
  final List<CartItem> items;
  final double total;
  final DateTime date;
  final String status;
  const Order({
    required this.id,
    required this.items,
    required this.total,
    required this.date,
    required this.status,
  });
}

String money(double v) => '${v.toStringAsFixed(2)} ر.س';

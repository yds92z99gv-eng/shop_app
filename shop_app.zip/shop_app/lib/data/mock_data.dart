import '../models/product.dart';

const categories = ['الكل', 'إلكترونيات', 'ملابس', 'المنزل', 'رياضة'];

String _img(String seed) => 'https://picsum.photos/seed/$seed/600/600';

final mockProducts = <Product>[
  Product(id: '1', name: 'سماعات لاسلكية', category: 'إلكترونيات', price: 249, oldPrice: 329, rating: 4.7, reviews: 214, image: _img('headphones'), description: 'سماعات بلوتوث بعزل ضوضاء فعّال وبطارية تدوم 30 ساعة.'),
  Product(id: '2', name: 'ساعة ذكية', category: 'إلكترونيات', price: 599, oldPrice: 749, rating: 4.5, reviews: 158, image: _img('smartwatch'), description: 'ساعة ذكية لتتبع النشاط والنوم مع شاشة AMOLED مقاومة للماء.'),
  Product(id: '3', name: 'شاحن سريع 65 واط', category: 'إلكترونيات', price: 89, rating: 4.4, reviews: 97, image: _img('charger'), description: 'شاحن GaN صغير الحجم بمنفذين USB-C لشحن الجوال واللابتوب.'),
  Product(id: '4', name: 'قميص قطن رجالي', category: 'ملابس', price: 79, oldPrice: 99, rating: 4.3, reviews: 63, image: _img('shirt'), description: 'قميص من القطن الخالص بقصة مريحة ومتوفر بعدة ألوان.'),
  Product(id: '5', name: 'جاكيت شتوي', category: 'ملابس', price: 289, rating: 4.6, reviews: 120, image: _img('jacket'), description: 'جاكيت دافئ بطبقة داخلية مبطنة ومقاوم للرياح.'),
  Product(id: '6', name: 'حذاء رياضي', category: 'رياضة', price: 349, oldPrice: 429, rating: 4.8, reviews: 301, image: _img('sneakers'), description: 'حذاء خفيف الوزن بنعل ماص للصدمات مناسب للجري اليومي.'),
  Product(id: '7', name: 'سجادة يوغا', category: 'رياضة', price: 69, rating: 4.2, reviews: 45, image: _img('yogamat'), description: 'سجادة يوغا مانعة للانزلاق بسماكة 6 مم.'),
  Product(id: '8', name: 'دمبل قابل للتعديل', category: 'رياضة', price: 199, rating: 4.6, reviews: 88, image: _img('dumbbell'), description: 'زوج دمبل قابل للتعديل من 2 إلى 20 كجم لتمارين المنزل.'),
  Product(id: '9', name: 'مصباح مكتب LED', category: 'المنزل', price: 59, rating: 4.4, reviews: 72, image: _img('lamp'), description: 'مصباح بإضاءة قابلة للتعديل وشحن USB.'),
  Product(id: '10', name: 'طقم أكواب قهوة', category: 'المنزل', price: 119, oldPrice: 150, rating: 4.5, reviews: 54, image: _img('mugs'), description: 'طقم 6 أكواب سيراميك بتصميم أنيق.'),
  Product(id: '11', name: 'وسادة طبية', category: 'المنزل', price: 99, rating: 4.7, reviews: 133, image: _img('pillow'), description: 'وسادة ميموري فوم لدعم الرقبة وتحسين النوم.'),
  Product(id: '12', name: 'حقيبة ظهر', category: 'ملابس', price: 159, rating: 4.5, reviews: 76, image: _img('backpack'), description: 'حقيبة ظهر مقاومة للماء بجيب مخصص للابتوب.'),
];

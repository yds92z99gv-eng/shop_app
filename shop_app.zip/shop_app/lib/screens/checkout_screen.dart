import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/product.dart';
import '../providers/providers.dart';

class CheckoutScreen extends ConsumerStatefulWidget {
  const CheckoutScreen({super.key});
  @override
  ConsumerState<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends ConsumerState<CheckoutScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _address = TextEditingController();
  String _payment = 'cash';

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _address.dispose();
    super.dispose();
  }

  String? _required(String? v) =>
      (v == null || v.trim().isEmpty) ? 'هذا الحقل مطلوب' : null;

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    final items = ref.read(cartProvider);
    final total = ref.read(grandTotalProvider);
    ref.read(ordersProvider.notifier).place(items, total);
    ref.read(cartProvider.notifier).clear();

    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        icon: const Icon(Icons.check_circle, color: Colors.green, size: 56),
        title: const Text('تم استلام طلبك'),
        content: const Text('شكراً لك! يمكنك متابعة الطلب من صفحة حسابي.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context), child: const Text('حسناً')),
        ],
      ),
    );
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final total = ref.watch(grandTotalProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('إتمام الطلب')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('بيانات التوصيل',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            TextFormField(
              controller: _name,
              validator: _required,
              decoration: const InputDecoration(
                  labelText: 'الاسم الكامل', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _phone,
              keyboardType: TextInputType.phone,
              validator: (v) =>
                  (v == null || v.trim().length < 9) ? 'رقم جوال غير صحيح' : null,
              decoration: const InputDecoration(
                  labelText: 'رقم الجوال', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _address,
              validator: _required,
              maxLines: 2,
              decoration: const InputDecoration(
                  labelText: 'العنوان', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 20),
            const Text('طريقة الدفع',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            SegmentedButton<String>(
              segments: const [
                ButtonSegment(
                    value: 'cash',
                    label: Text('عند الاستلام'),
                    icon: Icon(Icons.payments_outlined)),
                ButtonSegment(
                    value: 'card',
                    label: Text('بطاقة'),
                    icon: Icon(Icons.credit_card)),
              ],
              selected: {_payment},
              onSelectionChanged: (s) => setState(() => _payment = s.first),
            ),
            if (_payment == 'card')
              const Padding(
                padding: EdgeInsets.only(top: 8),
                child: Text('الدفع بالبطاقة تجريبي حالياً وسيُربط ببوابة دفع لاحقاً.',
                    style: TextStyle(color: Colors.grey, fontSize: 12)),
              ),
          ],
        ),
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: FilledButton(
            style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(50)),
            onPressed: _submit,
            child: Text('تأكيد الطلب • ${money(total)}'),
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/providers.dart';
import 'orders_screen.dart';

class ProfileScreen extends ConsumerStatefulWidget {
  const ProfileScreen({super.key});
  @override
  ConsumerState<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends ConsumerState<ProfileScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _email = TextEditingController();

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(userProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('حسابي')),
      body: user == null ? _loginForm() : _profile(user),
    );
  }

  Widget _loginForm() {
    return Form(
      key: _formKey,
      child: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          const SizedBox(height: 24),
          const Icon(Icons.storefront, size: 72),
          const SizedBox(height: 8),
          const Center(
              child: Text('مرحباً بك في متجري',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
          const SizedBox(height: 24),
          TextFormField(
            controller: _name,
            validator: (v) => (v == null || v.trim().isEmpty) ? 'أدخل اسمك' : null,
            decoration: const InputDecoration(
                labelText: 'الاسم', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _email,
            keyboardType: TextInputType.emailAddress,
            validator: (v) =>
                (v == null || !v.contains('@')) ? 'بريد إلكتروني غير صحيح' : null,
            decoration: const InputDecoration(
                labelText: 'البريد الإلكتروني', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 16),
          FilledButton(
            style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(50)),
            onPressed: () {
              if (_formKey.currentState!.validate()) {
                ref.read(userProvider.notifier).login(_name.text.trim());
              }
            },
            child: const Text('تسجيل الدخول'),
          ),
          const SizedBox(height: 8),
          const Text('تسجيل دخول تجريبي، وسيُربط بنظام مصادقة حقيقي لاحقاً.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey, fontSize: 12)),
        ],
      ),
    );
  }

  Widget _profile(String name) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        ListTile(
          leading: CircleAvatar(
              radius: 28, child: Text(name.characters.first.toUpperCase())),
          title: Text(name,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          subtitle: const Text('عميل'),
        ),
        const Divider(),
        ListTile(
          leading: const Icon(Icons.receipt_long_outlined),
          title: const Text('طلباتي'),
          trailing: const Icon(Icons.chevron_left),
          onTap: () => Navigator.push(
              context, MaterialPageRoute(builder: (_) => const OrdersScreen())),
        ),
        ListTile(
          leading: const Icon(Icons.logout, color: Colors.red),
          title: const Text('تسجيل الخروج'),
          onTap: () => ref.read(userProvider.notifier).logout(),
        ),
      ],
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/product.dart';
import '../providers/providers.dart';
import '../widgets/product_card.dart';
import 'checkout_screen.dart';

class CartScreen extends ConsumerWidget {
  const CartScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final items = ref.watch(cartProvider);
    final subtotal = ref.watch(subtotalProvider);
    final shipping = ref.watch(shippingProvider);
    final total = ref.watch(grandTotalProvider);
    final cart = ref.read(cartProvider.notifier);

    return Scaffold(
      appBar: AppBar(title: const Text('السلة')),
      body: items.isEmpty
          ? const Center(child: Text('سلتك فارغة'))
          : Column(
              children: [
                Expanded(
                  child: ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: items.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (_, i) {
                      final it = items[i];
                      return Card(
                        child: Padding(
                          padding: const EdgeInsets.all(8),
                          child: Row(children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(10),
                              child: SizedBox(
                                  width: 76,
                                  height: 76,
                                  child: ProductImage(url: it.product.image)),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(it.product.name,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(fontWeight: FontWeight.w600)),
                                  const SizedBox(height: 4),
                                  Text(money(it.total)),
                                  Row(children: [
                                    IconButton(
                                        visualDensity: VisualDensity.compact,
                                        onPressed: () => cart.decrement(it.product),
                                        icon: const Icon(Icons.remove_circle_outline)),
                                    Text('${it.qty}',
                                        style: const TextStyle(fontWeight: FontWeight.bold)),
                                    IconButton(
                                        visualDensity: VisualDensity.compact,
                                        onPressed: () => cart.add(it.product),
                                        icon: const Icon(Icons.add_circle_outline)),
                                  ]),
                                ],
                              ),
                            ),
                            IconButton(
                                onPressed: () => cart.remove(it.product),
                                icon: const Icon(Icons.delete_outline, color: Colors.red)),
                          ]),
                        ),
                      );
                    },
                  ),
                ),
                SafeArea(
                  top: false,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                    child: Column(children: [
                      _row('المجموع', money(subtotal)),
                      _row('الشحن', shipping == 0 ? 'مجاني' : money(shipping)),
                      const Divider(),
                      _row('الإجمالي', money(total), bold: true),
                      const SizedBox(height: 8),
                      FilledButton(
                        style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(50)),
                        onPressed: () => Navigator.push(context,
                            MaterialPageRoute(builder: (_) => const CheckoutScreen())),
                        child: const Text('إتمام الطلب'),
                      ),
                    ]),
                  ),
                ),
              ],
            ),
    );
  }

  Widget _row(String a, String b, {bool bold = false}) {
    final s = TextStyle(fontWeight: bold ? FontWeight.bold : null, fontSize: bold ? 17 : 14);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [Text(a, style: s), Text(b, style: s)]),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/product.dart';
import '../providers/providers.dart';
import '../widgets/product_card.dart';

class ProductDetailsScreen extends ConsumerWidget {
  final Product product;
  const ProductDetailsScreen({super.key, required this.product});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isFav = ref.watch(favoritesProvider).contains(product.id);
    final primary = Theme.of(context).colorScheme.primary;

    return Scaffold(
      appBar: AppBar(
        actions: [
          IconButton(
            onPressed: () => ref.read(favoritesProvider.notifier).toggle(product.id),
            icon: Icon(isFav ? Icons.favorite : Icons.favorite_border,
                color: isFav ? Colors.red : null),
          ),
        ],
      ),
      body: ListView(
        children: [
          AspectRatio(aspectRatio: 1, child: ProductImage(url: product.image)),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(product.name,
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Row(children: [
                  const Icon(Icons.star, size: 18, color: Colors.amber),
                  Text(' ${product.rating}  (${product.reviews} تقييم)'),
                ]),
                const SizedBox(height: 12),
                Row(children: [
                  Text(money(product.price),
                      style: TextStyle(
                          fontSize: 22, fontWeight: FontWeight.bold, color: primary)),
                  if (product.oldPrice != null) ...[
                    const SizedBox(width: 12),
                    Text(money(product.oldPrice!),
                        style: const TextStyle(
                            decoration: TextDecoration.lineThrough, color: Colors.grey)),
                  ],
                ]),
                const SizedBox(height: 16),
                const Text('الوصف',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                const SizedBox(height: 6),
                Text(product.description, style: const TextStyle(height: 1.6)),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: FilledButton.icon(
            style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(50)),
            onPressed: () {
              ref.read(cartProvider.notifier).add(product);
              ScaffoldMessenger.of(context)
                ..hideCurrentSnackBar()
                ..showSnackBar(const SnackBar(
                    content: Text('تمت الإضافة إلى السلة'),
                    duration: Duration(seconds: 1)));
            },
            icon: const Icon(Icons.add_shopping_cart),
            label: const Text('أضف إلى السلة'),
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/product.dart';
import '../providers/providers.dart';

class OrdersScreen extends ConsumerWidget {
  const OrdersScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final orders = ref.watch(ordersProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('طلباتي')),
      body: orders.isEmpty
          ? const Center(child: Text('لا توجد طلبات بعد'))
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: orders.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (_, i) {
                final o = orders[i];
                final d = o.date;
                return Card(
                  child: ExpansionTile(
                    title: Text('طلب ${o.id}',
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text('${d.year}/${d.month}/${d.day} • ${o.status}'),
                    trailing: Text(money(o.total)),
                    children: [
                      for (final it in o.items)
                        ListTile(
                          dense: true,
                          title: Text(it.product.name),
                          trailing: Text('× ${it.qty}'),
                        ),
                    ],
                  ),
                );
              },
            ),
    );
  }
}
